package ir.kitgroup.partnerManagement.feature.login.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import ir.kitgroup.partnerManagement.R
import ir.kitgroup.partnerManagement.core.ui.components.CustomButton
import ir.kitgroup.partnerManagement.core.ui.components.CustomEditTextField
import ir.kitgroup.partnerManagement.core.ui.theme.LocalPartnerManagementColors
import ir.kitgroup.partnerManagement.feature.home.navigation.BottomNavItem
@Composable
fun LoginScreen(
    navController: NavController,
    viewModel: LoginViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.effects.collect { effect ->
            when (effect) {
                LoginEffect.NavigateToMain -> {
                    navController.navigate(
                        BottomNavItem.Dashboard.route
                    ) {
                        popUpTo("login") {
                            inclusive = true
                        }
                        launchSingleTop = true
                    }
                }
            }
        }
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl
    ) {

        Box(
            modifier = Modifier.fillMaxSize()
        ) {

            LoginContent(
                uiState = uiState,
                onUsernameChange = viewModel::onUsernameChange,
                onPasswordChange = viewModel::onPasswordChange,
                onLoginClick = viewModel::onLoginClick,
                onSettingClick = viewModel::onOpenServerDialog
            )

            if (uiState.isServerDialogVisible) {
                ServerAddressDialog(
                    initialAddress = uiState.currentServerAddress,
                    errorMessage = uiState.serverAddressError,
                    isLoading = uiState.isTestingServer,
                    onDismissRequest = viewModel::onDismissServerDialog,
                    onSaveClick = viewModel::onSaveServerAddress
                )
            }
        }
    }
}

@Composable
private fun LoginContent(
    uiState: LoginUiState,
    onUsernameChange: (String) -> Unit,
    onPasswordChange: (String) -> Unit,
    onLoginClick: () -> Unit,
    onSettingClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()
    val appColors = LocalPartnerManagementColors.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(appColors.appBackground)
         /*   .pointerInput(Unit) {
                detectTapGestures {
                    focusManager.clearFocus()
                }
            }*/
            .padding(horizontal = 32.dp)
            .verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(80.dp))

        Image(
            painter = painterResource(id = R.drawable.ic_logo),
            contentDescription = stringResource(id = R.string.app_name),
            modifier = Modifier
                .fillMaxWidth(0.7f)
                .padding(bottom = 40.dp),
            contentScale = ContentScale.Fit
        )

        CustomEditTextField(
            value = uiState.username,
            onValueChange = onUsernameChange,
            label = stringResource(R.string.label_username),
            placeholder = stringResource(R.string.hint_enter_your_username),
            leadingIcon = painterResource(R.drawable.ic_user_name),
            errorMessage = uiState.usernameError
        )

        Spacer(modifier = Modifier.height(20.dp))

        CustomEditTextField(
            value = uiState.password,
            onValueChange = onPasswordChange,
            label = stringResource(R.string.label_password),
            placeholder = stringResource(R.string.hint_enter_your_password),
            leadingIcon = painterResource(R.drawable.ic_lock),
            isPasswordField = true,
            errorMessage = uiState.passwordError
        )

        uiState.loginError?.let { error ->
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = error,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(50.dp))

        CustomButton(
            text = stringResource(R.string.label_login),
            onClick = {
                focusManager.clearFocus()
                onLoginClick()
            },
            icon = Icons.AutoMirrored.Filled.Login,
            isLoading = uiState.isLoading
        )

        Spacer(modifier = Modifier.height(10.dp))

        CustomButton(
            text = stringResource(R.string.label_server_setting),
            onClick = onSettingClick,
            icon = Icons.Default.Dns,
            colors = ButtonDefaults.buttonColors(
                containerColor = appColors.tableHeaderBackground,
                contentColor = appColors.textPrimary
            )
        )

        Spacer(modifier = Modifier.height(40.dp))
    }
}
