package ir.kitgroup.partnerManagement.feature.dashboard.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import ir.kitgroup.partnerManagement.R
import ir.kitgroup.partnerManagement.core.ui.theme.*
import ir.kitgroup.partnerManagement.core.ui.util.SideCurvedHeaderShape
import ir.kitgroup.partnerManagement.feature.dashboard.model.*
import androidx.compose.material3.MaterialTheme.typography
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import ir.kitgroup.partnerManagement.core.ui.components.SectionTitle
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.hilt.navigation.compose.hiltViewModel
import ir.kitgroup.partnerManagement.core.ui.SessionViewModel
import ir.kitgroup.partnerManagement.core.ui.components.StatusBadge
import ir.kitgroup.partnerManagement.core.ui.util.UserRole
import ir.kitgroup.partnerManagement.navigation.Screen
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.Color.Companion.Red
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.kitgroup.partnerManagement.core.database.model.MeetingWithDetail
import ir.kitgroup.partnerManagement.core.ui.components.CustomHeader
import ir.kitgroup.partnerManagement.core.ui.util.DataState
import ir.kitgroup.partnerManagement.core.ui.util.MeetingStatus
import ir.kitgroup.partnerManagement.core.ui.util.MeetingType
import ir.kitgroup.partnerManagement.core.ui.util.SYNC_AFTER_CONTRACT_SAVE
import ir.kitgroup.partnerManagement.core.ui.util.SYNC_AFTER_ORGANIZATION_SAVE
import ir.kitgroup.partnerManagement.core.ui.util.UiEvent
import ir.kitgroup.partnerManagement.core.ui.util.formatJalaliDate
import ir.kitgroup.partnerManagement.feature.home.navigation.BottomNavItem
import ir.kitgroup.partnerManagement.feature.meeting.ui.DetailRow
import ir.kitgroup.partnerManagement.feature.meeting.ui.MeetingTypeChip

@Composable
fun DashboardScreen(
    navController: NavController,
    modifier: Modifier = Modifier,
    sessionViewModel: SessionViewModel = hiltViewModel(),
    dashboardViewModel: DashboardViewModel = hiltViewModel(),
    onSyncDataClick: () -> Unit = {},
    onUploadDataClick: () -> Unit = {}
) {
    val todayMeetings by dashboardViewModel.todayMeetings.collectAsStateWithLifecycle()
    val statistics by dashboardViewModel.statistics.collectAsStateWithLifecycle()

    val roleCode by sessionViewModel.roleCode.collectAsState()

    val currentRole = remember(roleCode) { UserRole.fromCode(roleCode.toString()) }
    val isSupervisor = currentRole == UserRole.SUPERVISOR

    val syncState by dashboardViewModel.syncState
        .collectAsStateWithLifecycle()

    val uploadState by dashboardViewModel.uploadState
        .collectAsStateWithLifecycle()

    val isSyncing =
        syncState is DataState.Loading

    val isUploading =
        uploadState is DataState.Loading

    val snackbarHostState =
        remember { SnackbarHostState() }

    val context =
        LocalContext.current

    val currentBackStackEntry = remember(navController) {
        navController.getBackStackEntry(BottomNavItem.Dashboard.route)
    }

    val shouldSyncAfterContractSave by
    currentBackStackEntry
        .savedStateHandle
        .getStateFlow(
            SYNC_AFTER_CONTRACT_SAVE,
            false
        )
        .collectAsStateWithLifecycle()

    val shouldSyncAfterOrganizationCreate by currentBackStackEntry
        .savedStateHandle
        .getStateFlow(
            SYNC_AFTER_ORGANIZATION_SAVE,
            false
        ).collectAsStateWithLifecycle()

    LaunchedEffect(shouldSyncAfterOrganizationCreate) {
        if (shouldSyncAfterOrganizationCreate) {
            // اول flag را خاموش می‌کنیم
            currentBackStackEntry.savedStateHandle[SYNC_AFTER_ORGANIZATION_SAVE] = false
            // سپس سینک را اجرا می‌کنیم
            dashboardViewModel.onReceiveDataClick()
        }
    }
    LaunchedEffect(
        shouldSyncAfterContractSave
    ) {
        if (shouldSyncAfterContractSave) {

            currentBackStackEntry
                .savedStateHandle[
                SYNC_AFTER_CONTRACT_SAVE
            ] = false

            dashboardViewModel
                .onReceiveDataClick()
        }
    }
    LaunchedEffect(dashboardViewModel.uiEvent) {
        dashboardViewModel.uiEvent.collect { event ->
            when (event) {
                is UiEvent.ShowMessage -> {
                    snackbarHostState.showSnackbar(
                        event.message.asString(context)
                    )
                }

                is UiEvent.ShowError -> {
                    snackbarHostState.showSnackbar(
                        event.error.asString(context)
                    )
                }
            }
        }
    }

    val summaryItems = listOf(
        SummaryCardData(
            icon = Icons.Filled.Domain,
            iconColor = Orange,
            value = (statistics?.totalVisits ?: 0).toString(),
            title = stringResource(R.string.label_total_meetings),
            accent = Orange
        ),
        SummaryCardData(
            icon = Icons.Filled.Inventory2,
            iconColor = Blue,
            value = (statistics?.totalAssignedStands ?: 0).toString(),
            title = stringResource(R.string.label_total_assigned_stands),
            accent = Blue
        ),
        SummaryCardData(
            icon = Icons.Filled.ConfirmationNumber,
            iconColor = Purple,
            value = (statistics?.totalAssignedSerials ?: 0).toString(),
            title = stringResource(R.string.label_total_assigned_serials),
            accent = Purple
        ),
        SummaryCardData(
            icon = Icons.Filled.AssignmentTurnedIn,
            iconColor = Green,
            value = (statistics?.activeContractsCount ?: 0).toString(),
            title = stringResource(R.string.label_total_active_contracts_count),
            accent = Green
        ),
        SummaryCardData(
            icon = Icons.Filled.Warning,
            iconColor = Red,
            value = (statistics?.totalWarningsRegistered ?: 0).toString(),
            title = stringResource(R.string.label_total_warnings_registered),
            accent = Red
        )
    )
    val fullName by sessionViewModel.fullName.collectAsState()

    val userFullName =
        if (!fullName.isNullOrBlank()) {
            stringResource(R.string.label_welcome_user, fullName!!.trim())
        } else {
            stringResource(R.string.nav_dashboard)
        }

    Scaffold(modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = {
            SnackbarHost(
                hostState = snackbarHostState
            )
        }
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            )
            {
                CustomHeader(
                    title = userFullName.toString(),
                    showBackButton = false
                )
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(start = 8.dp, end = 8.dp, top = 4.dp),
                    contentPadding = PaddingValues(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // بخش عملیات همگام‌سازی و سینک داده‌ها
                    item {
                        DataSyncSection(
                            isSyncing = isSyncing,
                            isUploading = isUploading,
                            onSyncClick = dashboardViewModel::onReceiveDataClick,
                            onUploadClick = dashboardViewModel::onSendDataClick
                        )
                    }

                    item { SummarySection(summaryItems) }
                    item { Spacer(Modifier.width(6.dp)) }
                    item {
                        QuickActionsSection(
                            onQuickContractClick = {
                                dashboardViewModel.checkCanNavigateToAddContract {
                                    navController.navigate(Screen.AddContract.route)
                                }
                            },
                            onQuickOrganizationClick = {
                                dashboardViewModel.checkCanNavigateToAddOrganization {
                                    navController.navigate(Screen.AddOrganization.route)
                                }
                            },

                            onQuickMeetingClick = {
                                dashboardViewModel.checkCanNavigateToAddMeeting {
                                    navController.navigate(Screen.AddMeeting.createRoute())
                                }
                            },
                            onQuickContractOfferClick =
                            {
                                dashboardViewModel.checkCanNavigateToAddOffer {
                                    navController.navigate(Screen.AddContractOffer.route)
                                }
                            }
                        )
                    }
                    item { Spacer(Modifier.width(6.dp)) }
                    item {
                        QuickAccessSection(
                            onContractClick = { navController.navigate(Screen.ContractsList.route) },
                            onAdvertisingClick = {
                                if (isSupervisor) {
                                    navController.navigate(Screen.AdvertisingStandMenu.route)
                                } else {
                                    navController.navigate(
                                        Screen.AssignedStandsOrganizationList.route
                                    )
                                }
                            },
                            onReportClick = { navController.navigate(Screen.ReportMenu.route) },
                            onMapClick = {
                                navController.navigate(
                                    Screen.Map.route
                                )
                            }
                        )
                    }
                    item { Spacer(Modifier.width(6.dp)) }
                    item {
                        SectionTitle(
                            stringResource(R.string.label_schedule_title),
                            Icons.Default.Schedule
                        )
                    }

                    if (todayMeetings.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(
                                        alpha = 0.3f
                                    )
                                )
                            ) {
                                Text(
                                    text = stringResource(R.string.msg_no_meeting_register_today),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    textAlign = TextAlign.Center,
                                    style = typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        items(
                            items = todayMeetings,
                            key = { it.meeting.meetingId }
                        ) { item ->
                            val meetingEntity = item.meeting
                            val isEditableScheduledPhysicalVisit = meetingEntity.status == 1

                            MeetingCard(
                                item = item,
                                isSupervisor = isSupervisor,
                                onClick = {
                                    /*    if (isEditableScheduledPhysicalVisit) {
                                            navController.navigate(
                                                Screen.AddMeeting.createRoute(
                                                    meetingId = meetingEntity.meetingId
                                                )
                                            )
                                        } else {*/
                                    navController.navigate(
                                        Screen.MeetingDetail.createRoute(
                                            meetingId = meetingEntity.meetingId
                                        )
                                    )
                                    // }
                                }
                            )
                        }
                    }

                    /*         item {
                                 SectionTitle(
                                     stringResource(R.string.label_schedule_title),
                                     Icons.Default.Schedule
                                 )
                             }
                             items(
                                 items = demoMeetings,
                                 key = { it.meetingId }
                             ) { item ->
                                 val isEditableScheduledPhysicalVisit =
                                     item.status == 1

                                 VisitCard(
                                     item = item,
                                     isSupervisor = isSupervisor,
                                     onClick = {
                                         if (isEditableScheduledPhysicalVisit) {
                                             navController.navigate(
                                                 Screen.AddMeeting.createRoute(
                                                     meetingId = item.meetingId
                                                 )
                                             )
                                         } else {
                                             navController.navigate(
                                                 Screen.MeetingDetail.createRoute(
                                                     meetingId = item.meetingId
                                                 )
                                             )
                                         }
                                     }
                                 )
                             }*/
                }

            }
        }
    }

}

@Composable
private fun DashboardHeader(
    fullName: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = MaterialTheme.colorScheme.primary,
                shape = SideCurvedHeaderShape(50f)
            )
            .windowInsetsPadding(WindowInsets.statusBars)
            .height(64.dp)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = if (fullName.isBlank()) {
                stringResource(R.string.greeting_text)
            } else {
                "$fullName خوش آمدی "
            },
            color = MaterialTheme.colorScheme.onPrimary,
            style = typography.titleLarge
        )
        //  NotificationIcon()
    }
}


@Composable
private fun DataSyncSection(
    isSyncing: Boolean,
    isUploading: Boolean,
    onSyncClick: () -> Unit,
    onUploadClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        ),
        border = BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SyncActionCardButton(
                modifier = Modifier.weight(1f),
                title = stringResource(R.string.label_receive_data),
                subtitle = stringResource(R.string.label_update_data),
                icon = Icons.Default.Sync,
                accentColor = PartnerManagementTheme.colors.infoContainer,
                iconTint = PartnerManagementTheme.colors.onInfoContainer,
                isLoading = isSyncing,
                onClick = onSyncClick
            )

            SyncActionCardButton(
                modifier = Modifier.weight(1f),
                title = stringResource(R.string.label_send_data),
                subtitle = stringResource(R.string.label_transfer_changes),
                icon = Icons.Default.CloudUpload,
                accentColor = PartnerManagementTheme.colors.successContainer,
                iconTint = PartnerManagementTheme.colors.onSuccessContainer,
                isLoading = isUploading,
                onClick = onUploadClick
            )
        }
    }
}

@Composable
private fun SyncActionCardButton(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    iconTint: Color,
    isLoading: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        enabled = !isLoading,
        modifier = modifier.height(64.dp),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        shadowElevation = 1.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(accentColor),
                contentAlignment = Alignment.Center
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = iconTint
                    )
                } else {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = iconTint,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = title,
                    style = typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun NotificationIcon() {
    Box(
        modifier = Modifier.size(32.dp),
        contentAlignment = Alignment.Center
    ) {

        Icon(
            painter = painterResource(R.drawable.ic_bell),
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(24.dp)
        )
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(4.dp, (-4).dp)
                .size(16.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.error),
            contentAlignment = Alignment.Center
        ) {
            Text("9", color = MaterialTheme.colorScheme.onError, fontSize = 9.sp)
        }
    }
}


@Composable
private fun SummarySection(
    summaryItems: List<SummaryCardData>,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {

        SectionTitle(stringResource(R.string.label_summary_title))
        Spacer(Modifier.height(6.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(horizontal = 4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(summaryItems) { item ->
                SummaryCard(
                    data = item,
                    modifier = Modifier.width(130.dp)
                )
            }
        }
    }
}

@Composable
private fun SummaryCard(data: SummaryCardData, modifier: Modifier) {
    Card(
        modifier = modifier.height(140.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = data.accent.copy(alpha = 0.08f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {

            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(data.iconColor.copy(.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(data.icon, null, tint = data.iconColor)
            }

            Text(
                data.value,
                color = MaterialTheme.colorScheme.onSurface,
                style = typography.displayMedium
            )

            Text(
                data.title,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                style = typography.labelMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(20))
                    .background(data.accent)
            )
        }
    }
}


@Composable
private fun QuickActionsSection(
    onQuickContractClick: () -> Unit,
    onQuickOrganizationClick: () -> Unit,
    onQuickMeetingClick: () -> Unit,
    onQuickContractOfferClick: () -> Unit,
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SectionTitle(stringResource(R.string.label_shortcut_title))

        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {

            QuickActionCard(
                title = stringResource(R.string.label_register_visit),
                icon = Icons.Filled.FactCheck,
                onClick = onQuickMeetingClick,
                modifier = Modifier.weight(1f)
            )
            QuickActionCard(
                title = stringResource(R.string.label_add_new_organization),
                icon = Icons.Filled.AddBusiness,
                onClick = onQuickOrganizationClick,
                modifier = Modifier.weight(1f)
            )
        }

     /*   Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            QuickActionCard(
                title = stringResource(R.string.label_contract),
                icon = Icons.Filled.AssignmentTurnedIn,
                onClick = onQuickContractClick,
                modifier = Modifier.weight(1f)
            )
            QuickActionCard(
                title = stringResource(R.string.label_contract_offer),
                icon = Icons.Filled.FactCheck,
                onClick = onQuickContractOfferClick,
                modifier = Modifier.weight(1f)
            )
        }*/
    }
}

@Composable
private fun QuickActionCard(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier
) {

    Card(
        modifier = modifier
            .height(64.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(Color.Transparent)
    ) {

        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            MaterialTheme.colorScheme.primary,
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                        )
                    )
                )
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {

            Icon(
                icon,
                null,
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(18.dp)
            )

            Spacer(Modifier.width(6.dp))

            Text(
                title, color = MaterialTheme.colorScheme.onPrimary, style = typography.labelMedium
            )
        }
    }
}

@Composable
fun QuickAccessSection(
    onContractClick: () -> Unit,
    onAdvertisingClick: () -> Unit,
    onReportClick: () -> Unit,
    onMapClick: () -> Unit
) {
    Column {

        SectionTitle(stringResource(R.string.label_quick_access))

        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            QuickAccessCard(
                title = stringResource(R.string.label_contract_organization),
                icon = Icons.Filled.Inventory2,
                backgroundColor = PartnerManagementTheme.colors.successContainer,
                iconTint = PartnerManagementTheme.colors.onSuccessContainer,
                onClick = onContractClick,
                modifier = Modifier.weight(1f)
            )
            QuickAccessCard(
                title = stringResource(R.string.label_advertising_stands),
                icon = Icons.Filled.Inventory2,
                backgroundColor = PartnerManagementTheme.colors.warningContainer,
                iconTint = PartnerManagementTheme.colors.onWarningContainer,
                onClick = onAdvertisingClick,
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            QuickAccessCard(
                title = stringResource(R.string.label_reports),
                icon = Icons.Filled.Assessment,
                backgroundColor = PartnerManagementTheme.colors.purpleContainer,
                iconTint = PartnerManagementTheme.colors.onPurpleContainer,
                onClick = onReportClick,
                modifier = Modifier.weight(1f)
            )
            QuickAccessCard(
                title = stringResource(R.string.label_map),
                icon = Icons.Filled.Map,
                backgroundColor = PartnerManagementTheme.colors.infoContainer,
                iconTint = PartnerManagementTheme.colors.onInfoContainer,
                onClick = onMapClick,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun QuickAccessCard(
    title: String,
    icon: ImageVector,
    backgroundColor: Color,
    iconTint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        modifier = modifier.height(104.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = backgroundColor
        ),
        border = BorderStroke(
            width = 1.dp,
            color = iconTint.copy(alpha = 0.10f)
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 0.dp,
            pressedElevation = 2.dp
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    horizontal = 12.dp,
                    vertical = 10.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier.size(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.height(7.dp))

            Text(
                text = title,
                style = typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun MeetingCard(
    item: MeetingWithDetail,
    isSupervisor: Boolean,
    onClick: () -> Unit,
) {
    val appColors = LocalPartnerManagementColors.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = appColors.cardBackground),
        border = BorderStroke(0.7.dp, appColors.border)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {

                // عنوان + Badge وضعیت
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.subjectVisitName,
                        style = typography.titleLarge,
                        color = appColors.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    StatusBadge(status = MeetingStatus.fromId(item.meeting.status))

                }

                Spacer(modifier = Modifier.height(8.dp))

                // چیپ نوع بازدید
                val meetingType = MeetingType.fromValue(item.meeting.type)

                MeetingTypeChip(
                    text = stringResource(id = meetingType.titleRes),
                    icon = meetingType.icon
                )
                Spacer(modifier = Modifier.height(6.dp))

                DetailRow(
                    icon = Icons.Default.Business,
                    text = item.organizationName
                )
                if (isSupervisor && !item.meeting.visitorId.isNullOrBlank()) {
                    val hasVisitor = !item.meeting.visitorName.isNullOrBlank() &&
                            item.meeting.visitorId != null

                    if (hasVisitor) {
                        Spacer(modifier = Modifier.height(6.dp))

                        DetailRow(
                            icon = Icons.Default.Person,
                            text = item.visitorName
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // نمایش تاریخ/زمان
                val dateTimeText = buildString {
                    append(formatJalaliDate(item.meeting.visitDate ?: "-"))
                    item.meeting.visitTime?.let { t ->
                        if (t.isNotBlank()) append("  |  $t")
                    }
                }

                DetailRow(
                    icon = Icons.Default.DateRange,
                    text = dateTimeText
                )

                Spacer(modifier = Modifier.height(6.dp))

            }
        }
    }


}

