package ir.kitgroup.partnerManagement.core.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cities")
data class CityEntity(

    @PrimaryKey
    val cityId: String,

    val name: String? = null,

    val stateCode: Int? = null,

    )